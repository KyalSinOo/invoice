const products = [
  {
    id: 1,
    name: "apple",
    price: 1200,
  },
  {
    id: 2,
    name: "orange",
    price: 1200,
  },
  {
    id: 3,
    name: "lime",
    price: 50,
  },
  {
    id: 4,
    name: "banana",
    price: 200,
  },
];
let rowCount = 1;
//selector
const app = document.querySelector("#app");
const newRecord = document.querySelector("#newRecord");
const product = document.querySelector("#product");
const quantity = document.querySelector("#quantity");
const records = document.querySelector("#records");
const inventories = document.querySelector("#inventories");
const newItem = document.querySelector("#newItem");
const newItemName = document.querySelector("#newItemName");
const newItemPrice = document.querySelector("#newItemPrice");
const recordRows = document.querySelector("#record-rows");
const recordsTotal = document.querySelector(".records-total");
const taxTotal = document.querySelector(".tax-total");
const subTotal = document.querySelector(".sub-total");

//functions
const createItem = (name, price) => {
  const div = document.createElement("div");
  div.className =
    "item-list border border-2 p-3 mb-3 d-flex justify-content-between";
  div.innerHTML = `
<p class="mb-0 item-name">${name}</p>
<p class="text-black-50 mb-0 item-price">${price}mmk</p>`;
  return div;
};
//create row
const createRecordRow = (productId, quantity) => {
  //information
  const currentProduct = products.find((el) => el.id == productId);
  let cost = currentProduct.price * quantity.valueAsNumber;
  // create newrow
  const tableRow = document.createElement("tr");
  tableRow.classList.add("record-row");
  tableRow.setAttribute("product-id", productId);
  tableRow.innerHTML = `
          <td class="record-no"></td>
          <td class="text-start record-product">${currentProduct.name}</td>
          <td class="text-end record-price">${currentProduct.price}</td>
          <td class="text-end ">
          <span>
          <i class="record-quantity-control record-quantity-decrement  bi bi-dash min"></i> 
          </span>
          <span class="record-quantity">${quantity.valueAsNumber}</span>
          <span>
          <i class="record-quantity-control record-quantity-increment bi bi-plus add"></i>
          </span>
          </td>
          <td class="text-end  position-relative ">
          <span class="record-cost">${cost}</span>
          <button class="btn btn-sm btn-primary position-absolute record-row-del">
          <i class="bi bi-trash3"></i>
          </button>
          </td>
          
    `;
  ///row remove
  tableRow.querySelector(".record-row-del").addEventListener("click", () => {
    if (confirm("Are You sure to remove product?")) {
      tableRow.classList.add("animate__animated", "animate__fadeOut");
      tableRow.addEventListener("animationend", () => {
        tableRow.remove();
        calculateTotal();
        tax();
        recordSubTotal();
      });
    }
  });
  ////item decre an increse
  ////////////////////////////cost function ///// pyin yan****
  let quantityNumber = tableRow.querySelector(".record-quantity");
  ////decrement
  tableRow.querySelector(".min").addEventListener("click", () => {
    quantityNumber.innerText--;

    let cost = tableRow.querySelector(".record-cost");
    cost.innerText =
      quantityNumber.innerText *
      tableRow.querySelector(".record-price").innerText;
    console.log(cost.innerText);
    // controlCost();
    calculateTotal();
    tax();
    recordSubTotal();
  });
  ///increment
  tableRow.querySelector(".add").addEventListener("click", () => {
    quantityNumber.innerText++;
    let cost = tableRow.querySelector(".record-cost");
    cost.innerText =
      quantityNumber.innerText *
      tableRow.querySelector(".record-price").innerText;
    // controlCost();
    calculateTotal();
    tax();
    recordSubTotal();
  });
  return tableRow;
};
// const controlCost=()=>{
//     let cost=tableRow.querySelector(".record-cost");
//     cost.innerText=quantityNumber.innerText*(tableRow.querySelector(".record-price")).innerText

//         console.log(cost.innerText);

// }

///quantity
// const controlCost=()=>{
//     let quantity=document.querySelector(".record-quantity").innerText;
//     // console.log(quantity);
//     let cost=document.querySelector(".record-cost");
//     // console.log(cost.innerText);
//     let price=document.querySelector(".record-price").innerText;
//     // console.log(price);
//     cost.innerText=quantity*price;
//     return cost;

// }
////////subtotal
const recordSubTotal = () => {
  let tax = taxTotal.innerText;
  let total = recordsTotal.innerText;
  subTotal.innerText = parseFloat(tax) + parseFloat(total);
  // console.log(subTotal.innerText);
  return tax;
};
//tax
const tax = () => {
  let total = recordsTotal.innerText;
  let tax = (total / 100) * 5;
  taxTotal.innerText = tax;
  //  console.log(tax);
  return tax;
};

//total
const calculateTotal = () => {
  // let total=0;
  // const allRecords=document.querySelectorAll(".record-cost");
  // allRecord.forEach(el=>{
  //     total+=parseFloat(el.innerText);
  // })
  // recordsTotal.innerText=total;
  recordsTotal.innerText = [
    ...document.querySelectorAll(".record-cost"),
  ].reduce((pv, cv) => pv + parseFloat(cv.innerText), 0);
};

//process
//generate product
products.forEach((el) => {
  // const newOption=document.createElement("option")
  // newOption.innerText=el.name
  // newOption.value=el.id
  product.append(new Option(el.name, el.id));
  inventories.append(createItem(el.name, el.price));
});

//add record
newRecord.addEventListener("submit", (e) => {
  e.preventDefault();

  const isExistedRow = document.querySelector(
    `[product-id='${product.value}']`
  );
  // console.log(isExistedRow);
  if (isExistedRow) {
    let currentQuantity = isExistedRow.querySelector(".record-quantity");
    let currentPrice = isExistedRow.querySelector(".record-price");
    let currentCost = isExistedRow.querySelector(".record-cost");
    let newQuantity =
      parseFloat(currentQuantity.innerText) + quantity.valueAsNumber;
    let newCost = currentPrice.innerText * newQuantity;
    currentQuantity.innerText = newQuantity;
    currentCost.innerText = newCost;
  } else {
    //create new row
    recordRows.append(createRecordRow(product.value, quantity));
  }

  newRecord.reset();
  //calculate total
  calculateTotal();
  tax();
  recordSubTotal();

  // console.log(cost);
  // console.log(product.value);//productId
  // console.log();
  // console.log(quantity.valueAsNumber);
  // const formData=new FormData(newRecord);
  // console.log(formData.get("product"));
  // console.log(formData.get("quantity"));
});
// product arrayupdate
newItem.addEventListener("submit", (e) => {
  e.preventDefault();
  let newItemId = products[products.length - 1].id + 1;
  // let newItemId=products.length++;
  const newItemObj = {
    id: newItemId,
    name: newItemName.value,
    price: newItemPrice.valueAsNumber,
  };
  products.push(newItemObj);
  // form reset
  newItem.reset();
  //ui update
  product.append(new Option(newItemObj.name, newItemObj.id));
  inventories.append(createItem(newItemObj.name, newItemObj.price));
  // console.log(products);
});
